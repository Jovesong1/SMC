var chartDom = document.getElementById('cpu');
var myChart = echarts.init(chartDom);
var chartDom1 = document.getElementById('ram');
var myChart1 = echarts.init(chartDom1);
var chartDom2 = document.getElementById('online');
var myChart2 = echarts.init(chartDom2);
var option;

var server_status = {
    cpu_model:"X5675",
    cpu_percentage:"9",
    cpu_core:"2",
    ram_min:"51",
    ram_max:"1024",
    ram_percentage:"1"
    
};


cpu = {
    // backgroundColor: '#36467E',
    title: [{
        text: server_status.cpu_percentage + '%',
        left: 'center',
        top: '55%',
        textStyle: {
            color: '#3f3f3f',
            fontSize: 20,
            fontWeight: 'bold',
        }
    },{
        text: '处理器',
        left: 'center',
        top: '10%',
        textStyle: {
            color: '#000000',
            fontSize: 15
        }
    }, {
        text: server_status.cpu_model+" / "+ server_status.cpu_core + " 核心",
        left: 'center',
        top: '72%',
        textStyle: {
            color: '#C0C0C0',
            fontSize: 14
        }
    }],
    angleAxis: {
        show: false,
        // 后面的180表示圆环的跨越的角度， 如max设置为100*360/270,startAngle设置为-135
        max: 100 * 360 / 180,
        type: 'value',
        startAngle: 180,
        splitLine: {
            show: false
        }
    },
    // 修改环形的宽度
    barMaxWidth: 10,
    radiusAxis: {
        show: false,
        type: 'category'
    },
    polar: {
        // 设置环形的位置
        center: ['50%', '70%'],
        // 设置环形大小
        radius: '150%'
    },
    series:[{
        type: 'bar',
        data: [
            {
                value: server_status.cpu_percentage,
                itemStyle: {
                    // 这里是已经达到进度的颜色
                    color: '#3399FF'
                }
            }
        ],
        barGap: '-100%',
        coordinateSystem: 'polar',
        z: 3
    }, {
        type: 'bar',
        data: [{
            value: 100,
            itemStyle: {
                // 这里是环形底色
                color: '#CCCCCC',
                borderWidth: 0
            }
        }],
        barGap: '-100%',
        coordinateSystem: 'polar',
        z: 1
    }]
}
ram = {
    // backgroundColor: '#36467E',
    title: [{
        text: server_status.ram_percentage + '%',
        left: 'center',
        top: '55%',
        textStyle: {
            color: '#3f3f3f',
            fontSize: 20,
            fontWeight: 'bold',
        }
    },{
        text: '运行内存',
        left: 'center',
        top: '10%',
        textStyle: {
            color: '#000000',
            fontSize: 15
        }
    }, {
        text: server_status.ram_min+" MB / "+ server_status.ram_max + " MB",
        left: 'center',
        top: '72%',
        textStyle: {
            color: '#C0C0C0',
            fontSize: 14
        }
    }],
    angleAxis: {
        show: false,
        // 后面的180表示圆环的跨越的角度， 如max设置为100*360/270,startAngle设置为-135
        max: 100 * 360 / 180,
        type: 'value',
        startAngle: 180,
        splitLine: {
            show: false
        }
    },
    // 修改环形的宽度
    barMaxWidth: 10,
    radiusAxis: {
        show: false,
        type: 'category'
    },
    polar: {
        // 设置环形的位置
        center: ['50%', '70%'],
        // 设置环形大小
        radius: '150%'
    },
    series:[{
        type: 'bar',
        data: [
            {
                value: server_status.ram_percentage,
                itemStyle: {
                    // 这里是已经达到进度的颜色
                    color: '#3399FF'
                }
            }
        ],
        barGap: '-100%',
        coordinateSystem: 'polar',
        z: 3
    }, {
        type: 'bar',
        data: [{
            value: 100,
            itemStyle: {
                // 这里是环形底色
                color: '#CCCCCC',
                borderWidth: 0
            }
        }],
        barGap: '-100%',
        coordinateSystem: 'polar',
        z: 1
    }]
}

online = {
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: [
        '2022/6/1 11:48',
        '2022/6/1 11:58',
        '2022/6/1 11:48',
        '2022/6/1 11:58',
        '2022/6/1 11:48',
        '2022/6/1 11:58','2022/6/1 11:48',
        '2022/6/1 11:58',
        '2022/6/1 11:48',
        '2022/6/1 11:58',
        '2022/6/1 11:48',
        '2022/6/1 11:58'
      ]
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        data: ['0', '2', '5', '10', '24', '25','21', '20', '9', '6', '5', '60'],
        type: 'line',
        areaStyle: {}
      }
    ]
  };




cpu && myChart.setOption(cpu);
ram && myChart1.setOption(ram);
online && myChart2.setOption(online);

